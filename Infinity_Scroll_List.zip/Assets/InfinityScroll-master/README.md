# InfinityScroll
These script will make your UnityGUI ScrollRects scroll infinitely. I used the HorizontalLayoutGroup and VerticalLayoutGroup components to display my UI elements.

Check out https://www.youtube.com/watch?v=6-dbROuf1zk

Note:
I updated the plugin. The video doesn't match perfectly anymore but it's essentially the same.

